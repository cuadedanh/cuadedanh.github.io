import sys
import xbmcgui
import xbmcplugin
import xbmc
import urllib.parse
import os, re, json
import xbmcvfs
from bs4 import BeautifulSoup
import requests
import time

# ID của addon (thư mục của addon)
ADDON_ID = 'plugin.video.myimdbfshare'
addon_handle = int(sys.argv[1])

# Đường dẫn đến tệp HTML đã tải về
IMDB_HTML_FILE = os.path.join(xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/resources'), 'IMDb Top 250 movies.html')

# URL tìm kiếm Fshare.vn (có thể cần điều chỉnh nếu Fshare thay đổi)
FSHARE_SEARCH_API_URL = "https://api.timfshare.com/v1/string-query-search?query="

TMDB_API_KEY = 'YOUR_TMDB_API_KEY'  # Thay bằng API key của bạn

PLOT_CACHE_FILE = os.path.join(xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/resources'), 'plots.json')

STRM_CONFIG_FILE = os.path.join(xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/resources'), 'strm_config.json')

def load_strm_dir():
    try:
        with open(STRM_CONFIG_FILE, 'r') as f:
            return json.load(f).get('strm_dir', '')
    except:
        return ''

def save_strm_dir(strm_dir):
    try:
        with open(STRM_CONFIG_FILE, 'w') as f:
            json.dump({'strm_dir': strm_dir}, f)
    except:
        pass


def load_plot_cache():
    if os.path.exists(PLOT_CACHE_FILE):
        with open(PLOT_CACHE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_plot_cache(cache):
    with open(PLOT_CACHE_FILE, 'w', encoding='utf-8') as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)

def get_vietnamese_plot(title, year, refresh=False):
    """
    Lấy plot tiếng Việt từ Wikipedia và lưu cache local.
    """
    cache = load_plot_cache()
    key = f"{title} ({year})"
    if not refresh and key in cache:
        return cache[key]

    # Tìm kiếm Wikipedia tiếng Việt
    try:
        search_url = f"https://vi.wikipedia.org/w/api.php?action=query&list=search&srsearch={urllib.parse.quote(title)}&format=json"
        resp = requests.get(search_url, timeout=10)
        data = resp.json()
        if data.get('query', {}).get('search'):
            page_title = data['query']['search'][0]['title']
            # Lấy nội dung trang
            page_url = f"https://vi.wikipedia.org/w/api.php?action=query&prop=extracts&exintro&explaintext&titles={urllib.parse.quote(page_title)}&format=json"
            resp2 = requests.get(page_url, timeout=10)
            data2 = resp2.json()
            pages = data2.get('query', {}).get('pages', {})
            for page in pages.values():
                plot = page.get('extract', '')
                if plot:
                    cache[key] = plot
                    save_plot_cache(cache)
                    return plot
    except Exception as e:
        xbmc.log(f"Lỗi lấy plot Wikipedia: {e}", level=xbmc.LOGWARNING)
    return ""

def refresh_plot_cache():
    """
    Làm mới toàn bộ plot từ Wikipedia và lưu lại.
    """
    movies = get_imdb_top250_from_file()
    cache = {}
    for movie in movies:
        plot = get_vietnamese_plot(movie['title'], movie['year'], refresh=True)
        cache[f"{movie['title']} ({movie['year']})"] = plot
    save_plot_cache(cache)
    xbmcgui.Dialog().ok("Hoàn tất", "Đã làm mới toàn bộ plot từ Wikipedia.")

def get_imdb_top250_from_file():
    """
    Lấy danh sách Top 250 IMDB từ tệp HTML cục bộ, bao gồm cả IMDb ID.
    """
    movies = []
    try:
        with open(IMDB_HTML_FILE, 'r', encoding='utf-8') as f:
            html_content = f.read()

        soup = BeautifulSoup(html_content, 'html.parser')

        # Duyệt qua từng item trong danh sách
        for item in soup.select('li.ipc-metadata-list-summary-item'):
            try:
                # 1. Lấy IMDb ID từ link tiêu đề
                link_element = item.select_one('a.ipc-title-link-wrapper')
                imdb_id = ""
                if link_element and 'href' in link_element.attrs:
                    match = re.search(r'(tt\d+)', link_element['href'])
                    if match:
                        imdb_id = match.group(1)

                # 2. Lấy tiêu đề và năm
                title_element = item.select_one('h3.ipc-title__text')
                if title_element:
                    title_full = title_element.get_text(strip=True)
                    title = title_full.split('.', 1)[1].strip() if '.' in title_full else title_full
                else: continue

                year_element = item.select_one('span.sc-4b408797-8.iurwGb.cli-title-metadata-item')
                year = year_element.get_text(strip=True) if year_element else "N/A"

                # 3. Lấy Rating và Poster
                rating_element = item.select_one('span.ipc-rating-star--rating')
                imdb_rating = rating_element.get_text(strip=True) if rating_element else "N/A"

                poster_element = item.select_one('img')
                poster_url = poster_element['src'] if poster_element and 'src' in poster_element.attrs else ""
                poster_url = poster_url.replace('./IMDb Top 250 movies_files/', '')

                # 4. Lấy Plot từ cache (Wikipedia)
                plot_vi = get_vietnamese_plot(title, year)

                movies.append({
                    'title': title,
                    'year': year,
                    'imdb_id': imdb_id, # THÊM MỚI
                    'imdb_rating': imdb_rating,
                    'poster': poster_url,
                    'plot': plot_vi
                })
            except Exception as e:
                continue
        return movies
    except Exception as e:
        xbmc.log(f"Lỗi đọc file IMDb: {e}", level=xbmc.LOGERROR)
        return []

def search_fshare(movie_title, movie_year=None, season=None, episode=None):
    if season and episode:
        # TV series: tìm theo tên + SxxExx
        search_query = f"{movie_title} S{int(season):02d}E{int(episode):02d}"
    else:
        # Movie: tìm theo tên + năm
        search_query = f"{movie_title} {movie_year or ''}".strip()
    
    fshare_results = timfshare(search_query)

    links = []
    if 'items' in fshare_results and isinstance(fshare_results['items'], list):
        for item in fshare_results['items']:
            size = item.get('info', {}).get('size', 0)
            links.append({'title': item.get('label', 'No Title'), 'url': item.get('path', ''),'size': size})
            
    return links

def search_fshare_manual():
    """
    Cho phép người dùng nhập từ khóa tìm kiếm từ bàn phím.
    """
    keyboard = xbmc.Keyboard('', 'Nhập tên phim cần tìm trên Fshare')
    keyboard.doModal()
    if keyboard.isConfirmed():
        query = keyboard.getText().strip()
        if query:
            show_fshare_links(query, '')

def create_strm_file(title, url, movie_info=None):
    """
    Tạo file .strm với tên chuẩn hóa để Kodi nhận diện chất lượng.
    """
    def parse_language_prefix(filename):
        langs = []
        prefix_match = re.match(r'^\s*\((.*?)\)\s*', filename)
        if prefix_match:
            prefix = prefix_match.group(1).upper()
            if any(x in prefix for x in ['THUYET MINH', 'TM']):
                langs.append('TM')
            if any(x in prefix for x in ['SUB VIET', 'SUBVIET', 'VIETSUB']):
                langs.append('VieSub')
            filename = filename[prefix_match.end():]
        return filename, langs

    def normalize_tech_part(tech_part):
        normalize_map = {
            # Độ phân giải
            '2160P': '2160p', '1080P': '1080p', '720P': '720p',
            '480P': '480p', '576P': '576p',
            # Nguồn
            'BLURAY': 'BluRay', 'BLU-RAY': 'BluRay', 'BDRIP': 'BDRip',
            'WEBRIP': 'WEBRip', 'WEB-DL': 'WEB-DL', 'WEBDL': 'WEB-DL',
            'HDTV': 'HDTV', 'DVDRIP': 'DVDRip', 'REMUX': 'REMUX',
            'AMZN': 'AMZN', 'NF': 'NF', 'HMAX': 'HMAX',
            'DSNP': 'DSNP', 'MA': 'MA', 'UHD': 'UHD',
            # Codec video
            'X264': 'x264', 'X265': 'x265',
            'H264': 'H.264', 'H.264': 'H.264',
            'H265': 'H.265', 'H.265': 'H.265',
            'HEVC': 'HEVC', 'AVC': 'AVC', 'AV1': 'AV1',
            # Codec audio
            'DTS-HD': 'DTS-HD', 'DTS': 'DTS', 'TRUEHD': 'TrueHD',
            'ATMOS': 'Atmos', 'DD5.1': 'DD5.1', 'DDP5.1': 'DDP5.1',
            'DDP': 'DDP', 'AAC': 'AAC', 'AC3': 'AC3',
            'FLAC': 'FLAC', 'MP3': 'MP3',
            # HDR
            'HDR10+': 'HDR10+', 'HDR10': 'HDR10', 'HDR': 'HDR',
            'DOLBY VISION': 'DV', 'DV': 'DV',
            # Ngôn ngữ
            'VIE': 'ViE', 'ENG': 'ENG', 'VIET': 'ViE',
            # Bit depth
            '10BIT': '10bit', '8BIT': '8bit',
        }
        tokens = tech_part.split('.')
        normalized = []
        for token in tokens:
            upper = token.upper()
            if upper in normalize_map:
                normalized.append(normalize_map[upper])
            else:
                normalized.append(token)
        return '.'.join(normalized)

    def parse_media_info(filename):
        info = {}
        # Tìm năm trong tên file kể cả trong ngoặc
        year_match = re.search(r'\b(19|20)\d{2}\b', filename)
        info['year'] = year_match.group(0) if year_match else ''

        # Thay (2008) → 2008, giữ lại năm làm mốc tách tên phim
        filename_clean = re.sub(r'\(((19|20)\d{2})\)', r'\1', filename)
        # Xóa các ngoặc khác không phải năm
        filename_clean = re.sub(r'\(.*?\)', '', filename_clean)
        # Xóa số thứ tự đầu như "02. "
        filename_clean = re.sub(r'^\d+\.\s*', '', filename_clean)
        filename_clean = re.sub(r'\s+', ' ', filename_clean).strip()

        # Tên phim = phần trước năm
        year_match2 = re.search(r'\b(19|20)\d{2}\b', filename_clean)
        if year_match2:
            title_part = filename_clean[:year_match2.start()]
        else:
            title_part = filename_clean
        title_part = re.sub(r'\.(mkv|mp4|wmv|iso|ts)$', '', title_part, flags=re.IGNORECASE)
        title_part = re.sub(r'[._]', ' ', title_part).strip()
        title_part = re.sub(r'[\s\-]+$', '', title_part)
        info['parsed_title'] = title_part

        return info

    # Xử lý tên file: tách prefix ngôn ngữ trước
    clean_title, lang_tags = parse_language_prefix(title)

    # Parse năm và tên phim
    media = parse_media_info(clean_title)

    # Lấy title và year
    movie_title = ''
    year = media['year']
    if movie_info:
        if movie_info.get('title'):
            movie_title = movie_info.get('title')
        year = movie_info.get('year', '') or year
    if not movie_title:
        movie_title = media['parsed_title']

    # Tạo bản clean để lấy tech_part
    # Thay (2008) → 2008 để giữ năm làm mốc
    clean_for_tech = re.sub(r'\(((19|20)\d{2})\)', r'\1', clean_title)
    # Xóa các ngoặc khác không phải năm
    clean_for_tech = re.sub(r'\(.*?\)', '', clean_for_tech)
    # Xóa số thứ tự đầu
    clean_for_tech = re.sub(r'^\d+\.\s*', '', clean_for_tech)
    clean_for_tech = re.sub(r'\s+', ' ', clean_for_tech).strip()

    # Lấy phần kỹ thuật từ năm trở đi
    year_match = re.search(r'\b(19|20)\d{2}\b', clean_for_tech)
    if year_match:
        tech_part = clean_for_tech[year_match.start():]
        tech_part = re.sub(r'\.(mkv|mp4|wmv|iso|ts)$', '', tech_part, flags=re.IGNORECASE)
        tech_part = tech_part.replace(' ', '.')
        tech_part = re.sub(r'\.+', '.', tech_part).strip('.')
        tech_part = normalize_tech_part(tech_part)
    else:
        tech_part = ''

    # Ghép tên phim + phần kỹ thuật + tag ngôn ngữ sau năm
    name_part = movie_title.replace(' ', '.')

    if tech_part and lang_tags:
        year_in_tech = re.search(r'\b(19|20)\d{2}\b', tech_part)
        if year_in_tech:
            insert_pos = year_in_tech.end()
            tech_part = tech_part[:insert_pos] + '.' + '.'.join(lang_tags) + tech_part[insert_pos:]
        else:
            tech_part = '.'.join(lang_tags) + '.' + tech_part

    safe_title = f"{name_part}.{tech_part}" if tech_part else name_part
    safe_title = re.sub(r'[\\/*?:"<>|()\[\]]', '_', safe_title)
    safe_title = re.sub(r'_+', '_', safe_title)
    safe_title = safe_title.strip('_').strip('.')

# Lấy thư mục đã lưu lần trước
    dialog = xbmcgui.Dialog()
    saved_dir = load_strm_dir()

    if saved_dir:
        choice = dialog.yesno(
            'Thư mục lưu .strm',
            f"Dùng lại thư mục:\n{saved_dir}",
            nolabel='Đổi thư mục',
            yeslabel='Dùng lại'
        )
        if choice:
            strm_dir = saved_dir
        else:
            strm_dir = dialog.browse(3, 'Chọn thư mục lưu file .strm', 'files')
            if not strm_dir:
                return
            save_strm_dir(strm_dir)
    else:
        strm_dir = dialog.browse(3, 'Chọn thư mục lưu file .strm', 'files')
        if not strm_dir:
            return
        save_strm_dir(strm_dir)

    strm_path = os.path.join(strm_dir, f"{safe_title}.strm")

    try:
        strm_file = xbmcvfs.File(strm_path, 'w')
        strm_file.write(url)
        strm_file.close()
        xbmc.log(f"Created STRM: {strm_path}", level=xbmc.LOGINFO)

        # Scan chỉ file vừa tạo vào library qua JSON-RPC
        import json as _json
        scan_query = _json.dumps({
            "jsonrpc": "2.0",
            "method": "VideoLibrary.Scan",
            "params": {
                "directory": strm_path,  # Chỉ scan đúng file này
                "showdialogs": False
            },
            "id": 1
        })
        xbmc.executeJSONRPC(scan_query)

        # Poll chờ scan xong tối đa 15 giây
        for _ in range(15):
            xbmc.sleep(1000)
            status_query = _json.dumps({
                "jsonrpc": "2.0",
                "method": "XBMC.GetInfoBooleans",
                "params": {"booleans": ["Library.IsScanning"]},
                "id": 2
            })
            result = _json.loads(xbmc.executeJSONRPC(status_query))
            if not result.get('result', {}).get('Library.IsScanning', False):
                break

        xbmcgui.Dialog().ok("Thành công", f"Đã tạo và thêm vào library:\n{safe_title}.strm")

    except Exception as e:
        xbmcgui.Dialog().ok("Lỗi", f"Không tạo được file:\n{e}")
        xbmc.log(f"STRM error: {e}", level=xbmc.LOGERROR)

def timfshare(query):
    query = query.replace("\n", "").replace(".", " ")
    query = query.replace('&ref=ref','')
    query = urllib.parse.quote_plus(query)
    api_timfshare = 'https://api.timfshare.com/v1/string-query-search?query='

    headers = {
        'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'
    }

    max_retries = 3
    for attempt in range(max_retries):
        try:
            response = requests.post(api_timfshare + query, headers=headers, timeout=10)
            response.raise_for_status()
            jsondata = response.json()
            break
        except requests.exceptions.RequestException as e:
            if attempt == max_retries - 1:
                notify("Không thể kết nối tới API sau 3 lần thử.")
                return {"content_type": "episodes", "items": []}

    items = []
    for i in jsondata.get('data', []):
        item = {}
        name = i.get('name', '')
        furl = i.get('url', '')
        filesize = float(i.get("size", 0))
        type_f = i.get('file_type', '')

        if furl:
            furl = re.search(r"(.*)\?", furl).group(1) if '?' in furl else furl
            link = f'plugin://plugin.video.vietmediaF?action=play&url={furl}'
            playable = type_f != '0'
        else:
            continue

        item["label"] = name
        item["is_playable"] = playable
        item["path"] = link
        item["thumbnail"] = 'fshare.png'
        item["icon"] = "fshareicon.png"
        item["label2"] = ""
        item["info"] = {'plot': '', 'size': filesize}
        items.append(item)

    data = {"content_type": "episodes", "items": items}
    valid_extensions = ['.mkv', '.mp4', '.wmv', '.iso', '.ISO', '.ts']

    new_items = []
    for item in data['items']:
        label = item['label']
        extension = label[label.rfind('.'):].lower()
        if extension in valid_extensions:
            new_items.append(item)

    data['items'] = new_items
    t = len(data['items'])

    if t == 0:
        notify("Không tìm thấy kết quả phù hợp.")
    return data

def list_movies():
    """
    Hiển thị danh sách phim Top 250 IMDB trong Kodi với đầy đủ ID cho Trakt.
    """
    xbmcplugin.setPluginCategory(addon_handle, 'IMDB Top 250 Movies')
    xbmcplugin.setContent(addon_handle, 'movies')

    # Menu tìm kiếm thủ công
    search_url = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'search_manual'})
    search_item = xbmcgui.ListItem('[🔍 Tìm kiếm Fshare thủ công]')
    search_item.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=search_url, listitem=search_item, isFolder=True)

    # Lấy danh sách phim đã có ID
    movies = get_imdb_top250_from_file()
    
    for i, movie in enumerate(movies):
        title_label = f"{i+1}. {movie['title']} ({movie['year']}) - ⭐ {movie['imdb_rating']}"
        list_item = xbmcgui.ListItem(title_label)

        # THIẾT LẬP INFO CHO KODI VÀ TRAKT
        # Việc gán mediatype và imdbnumber ở đây giúp Trakt nhận diện ngay từ menu
        video_info = {
            'title': movie['title'],
            'year': int(movie['year']) if movie['year'].isdigit() else None,
            'plot': movie.get('plot', ''),
            'rating': movie['imdb_rating'],
            'mediatype': 'movie',       # Khai báo phim lẻ
            'imdbnumber': movie['imdb_id'] # ID định danh cho Trakt
        }
        list_item.setInfo('video', video_info)

        # Gắn Poster
        poster_path = os.path.join(
            xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/resources/IMDb Top 250 movies_files'), 
            movie['poster']
        )
        list_item.setArt({'thumb': poster_path, 'icon': poster_path, 'poster': poster_path})

        # TRUYỀN ID SANG ROUTER
        # Khi nhấn vào phim, ID này sẽ được gửi sang hàm show_fshare_links
        url_params = {
            'action': 'search_fshare',
            'title': movie['title'],
            'year': movie['year'],
            'imdb': movie['imdb_id'] # Truyền ID tt...
        }
        url = sys.argv[0] + '?' + urllib.parse.urlencode(url_params)
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)

    # Các menu chức năng khác
    refresh_url = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'refresh_imdb'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=refresh_url, listitem=xbmcgui.ListItem('[🔄 Làm mới IMDb Top 250]'), isFolder=False)

    refresh_plot_url = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'refresh_plot'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=refresh_plot_url, listitem=xbmcgui.ListItem('[📖 Làm mới Plot Wikipedia]'), isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def show_fshare_links(movie_title, movie_year, imdb_id=None, tmdb_id=None, season=None, episode=None, tvshowtitle=None):
    content_type = 'movies' if not season else 'episodes'
    xbmcplugin.setContent(addon_handle, content_type)
    xbmcplugin.setPluginCategory(addon_handle, f'Links: {movie_title}')

    links = search_fshare(movie_title, movie_year, season=season, episode=episode)
    if not links:
        notify(f"Không tìm thấy link cho {movie_title}")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    links.sort(key=lambda x: x.get('size', 0), reverse=True)

    poster_path = ""
    plot_text = ""
    movie_info_local = None
    if not season:
        imdb_movies = get_imdb_top250_from_file()
        movie_info_local = next((m for m in imdb_movies if (imdb_id and m['imdb_id'] == imdb_id) or m['title'] == movie_title), None)
        if movie_info_local:
            poster_path = os.path.join(
                xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/resources/IMDb Top 250 movies_files'),
                movie_info_local.get('poster', '')
            )
            plot_text = movie_info_local.get('plot', '')

    list_items = []

    for i, link_info in enumerate(links):
        size = link_info.get('size', 0)
        size_str = f"{size/(1024**3):.2f} GB" if size >= 1024**3 else f"{size/(1024**2):.2f} MB"

        title_label = f"{i+1}: {link_info['title']} - ({size_str})"

        # URL gọi qua action play_trakt để set script.trakt.ids trước khi play
        play_params = {
            'action': 'play_trakt',
            'url': link_info['url'],
            'imdb': str(imdb_id) if imdb_id else '',
            'tmdb': str(tmdb_id) if tmdb_id else '',
            'title': movie_title,
            'year': str(movie_year) if movie_year else '',
            'season': str(season) if season else '',
            'episode': str(episode) if episode else '',
            'tvshowtitle': tvshowtitle or '',
        }
        play_url = sys.argv[0] + '?' + urllib.parse.urlencode(play_params)

        list_item = xbmcgui.ListItem(label=title_label, path=play_url)

        # Gán metadata vào ListItem
        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(movie_title)

        if plot_text:
            info_tag.setPlot(plot_text)

        if movie_year and str(movie_year).isdigit():
            info_tag.setYear(int(movie_year))

        ids = {}
        if imdb_id:
            ids['imdb'] = str(imdb_id)
            info_tag.setIMDBNumber(str(imdb_id))
        if tmdb_id:
            ids['tmdb'] = str(tmdb_id)
        if ids:
            info_tag.setUniqueIDs(ids, 'imdb' if imdb_id else 'tmdb')

        if season and episode:
            info_tag.setMediaType('episode')
            info_tag.setTvShowTitle(tvshowtitle or movie_title)
            info_tag.setSeason(int(season))
            info_tag.setEpisode(int(episode))
        else:
            info_tag.setMediaType('movie')

        if poster_path:
            list_item.setArt({'thumb': poster_path, 'poster': poster_path, 'fanart': poster_path, 'icon': poster_path})

        list_item.setProperty('IsPlayable', 'true')

        # Context menu
        strm_params = {
            'action': 'create_strm',
            'title': link_info['title'],
            'url': link_info['url'],
            'movie_title': movie_title,
            'movie_year': str(movie_year) if movie_year else '',
            'imdb': str(imdb_id) if imdb_id else '',
            'tmdb': str(tmdb_id) if tmdb_id else '',
            'movie_plot': plot_text,
            'movie_rating': movie_info_local.get('imdb_rating', '') if movie_info_local else '',
        }
        strm_url = sys.argv[0] + '?' + urllib.parse.urlencode(strm_params)
        list_item.addContextMenuItems([
            ('💾 Tạo file .strm', f'RunPlugin({strm_url})')
        ])

        list_items.append((play_url, list_item, False))

    xbmcplugin.addDirectoryItems(addon_handle, list_items)
    xbmcplugin.endOfDirectory(addon_handle)


def set_trakt_ids_and_play(play_url, imdb_id, tmdb_id, movie_title, movie_year, season=None, episode=None, tvshowtitle=None):
    import json as _json

    # Set script.trakt.ids vào Window(10000)
    if imdb_id or tmdb_id:
        trakt_ids = {}
        if imdb_id:
            trakt_ids['imdb'] = str(imdb_id)
        if tmdb_id:
            trakt_ids['tmdb'] = str(tmdb_id)
        xbmcgui.Window(10000).setProperty('script.trakt.ids', _json.dumps(trakt_ids))
        xbmc.log(f"Set script.trakt.ids: {_json.dumps(trakt_ids)}", level=xbmc.LOGINFO)

    # Dùng setResolvedUrl thay vì xbmc.Player().play() để tránh play 2 lần
    list_item = xbmcgui.ListItem(label=movie_title, path=play_url)
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(movie_title)

    if movie_year and str(movie_year).isdigit():
        info_tag.setYear(int(movie_year))

    ids = {}
    if imdb_id:
        ids['imdb'] = str(imdb_id)
        info_tag.setIMDBNumber(str(imdb_id))
    if tmdb_id:
        ids['tmdb'] = str(tmdb_id)
    if ids:
        info_tag.setUniqueIDs(ids, 'imdb' if imdb_id else 'tmdb')

    if season and episode:
        info_tag.setMediaType('episode')
        info_tag.setTvShowTitle(tvshowtitle or movie_title)
        info_tag.setSeason(int(season))
        info_tag.setEpisode(int(episode))
    else:
        info_tag.setMediaType('movie')

    # setResolvedUrl - Kodi đã biết đây là playable item, chỉ cần resolve URL
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=list_item)

def router(paramstring):
    """
    Router xử lý các yêu cầu từ Kodi, TMDB Helper và các lệnh nội bộ.
    """
    # Loại bỏ dấu '?' ở đầu nếu có và parse tham số
    params = dict(urllib.parse.parse_qsl(paramstring.lstrip('?')))

    if params:
        action = params.get('action')

        if action == 'search_manual':
            search_fshare_manual()

        elif action == 'search_fshare':
            # Hứng toàn bộ tham số định danh từ TMDB Helper hoặc List nội bộ
            movie_title = params.get('title')
            movie_year = params.get('year')
            imdb_id = params.get('imdb')
            tmdb_id = params.get('tmdb')
            
            # Các tham số dành riêng cho TV Show
            season = params.get('season')
            episode = params.get('episode')
            tvshowtitle = params.get('tvshowtitle')
            
            if movie_title:
                show_fshare_links(
                    movie_title, 
                    movie_year, 
                    imdb_id=imdb_id, 
                    tmdb_id=tmdb_id, 
                    season=season, 
                    episode=episode, 
                    tvshowtitle=tvshowtitle
                )

        
        elif action == 'refresh_imdb':
            refresh_imdb_top250()
            list_movies()

        elif action == 'refresh_plot':
            refresh_plot_cache()
            list_movies()

        elif action == 'create_strm':
            # Hứng dữ liệu để đóng gói file .strm
            # Đảm bảo truyền đủ ID vào info để file .strm sau này cũng scrobble được
            info = {
                'title': params.get('movie_title', params.get('title', '')),
                'year': params.get('movie_year', params.get('year', '')),
                'imdb_id': params.get('imdb_id', params.get('imdb', '')),
                'tmdb_id': params.get('tmdb', ''),
                'plot': params.get('movie_plot', ''),
                'rating': params.get('movie_rating', ''),
            }            
            create_strm_file(params.get('title', ''), params.get('url', ''), info)
        elif action == 'play_trakt':
            set_trakt_ids_and_play(
                play_url=params.get('url'),
                imdb_id=params.get('imdb'),
                tmdb_id=params.get('tmdb'),
                movie_title=params.get('title'),
                movie_year=params.get('year'),
                season=params.get('season') or None,
                episode=params.get('episode') or None,
                tvshowtitle=params.get('tvshowtitle') or None,
            )
    else:
        # Nếu không có tham số, hiển thị danh sách IMDb Top 250 mặc định
        list_movies()

def refresh_imdb_top250():
    """
    Tải lại file IMDb Top 250 và poster về thư mục addon.
    """
    import requests
    from bs4 import BeautifulSoup

    url = "https://www.imdb.com/chart/top/"
    html_path = os.path.join(xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/resources'), 'IMDb Top 250 movies.html')
    posters_dir = os.path.join(xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/resources/IMDb Top 250 movies_files'))

    if not os.path.exists(posters_dir):
        os.makedirs(posters_dir)

    response = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'})
    response.raise_for_status()
    html = response.text

    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html)

    soup = BeautifulSoup(html, 'html.parser')
    for row in soup.select('tbody.lister-list tr'):
        img = row.find('img')
        if img and img.get('src'):
            poster_url = img['src']
            poster_name = poster_url.split('/')[-1].split('?')[0]
            poster_path = os.path.join(posters_dir, poster_name)
            if not os.path.exists(poster_path):
                try:
                    img_data = requests.get(poster_url, timeout=10).content
                    with open(poster_path, 'wb') as pf:
                        pf.write(img_data)
                except Exception as e:
                    xbmc.log(f"Không tải được poster: {poster_url} - {e}", level=xbmc.LOGWARNING)
    xbmcgui.Dialog().ok("Hoàn tất", "Đã làm mới danh sách IMDb Top 250 và poster.")

if __name__ == '__main__':
    router(sys.argv[2][1:])